import requests
import sys

notes = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A","Bb", "B"]
octave_max = 8

def make_request(note, octave, datapath):
    link = "http://theremin.music.uiowa.edu/sound files/MIS/Piano_Other/piano/Piano.mf.{0}{1}.aiff".format(
        note, 
        octave
    )
    print (link)
    r = requests.get(link)
    with open('{0}/{1}{2}.aiff'.format(datapath, note, octave), 'wb') as f:
        f.write(r.content)

def download():
    for n in notes:
        for octave in range(1, octave_max):
            try:
                make_request('sounds/piano',n, octave)
            except:
                continue

download()