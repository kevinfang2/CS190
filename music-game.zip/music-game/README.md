# music-game

Play guitar hero with songs in JSON format in songs/

To run u need python3 and node >10?
1. npm install
2. pip install flask
3. python server.py
4. go to localhost:8000 and play

scrape piano files, taking from university of iowa

```
python3 scrapepiano.py
```

convert music files from aiff to ogg

```
for f in *.aiff; do ffmpeg -i "$f" "${f%.aiff}.ogg"; done
```
