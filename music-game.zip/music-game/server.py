from flask import Flask, request, render_template, send_from_directory, jsonify
import json
import os
import glob

def get_file_format(instrument, user_agent):
    if instrument == 'piano':
        if 'Chrome' in user_agent:
            file_format = 'ogg'
        else:
            file_format = 'aiff'
    else:
        file_format = 'wav'
    return file_format

def get_name_from_path(path):
    return path.split('/')[-1].split('.')[0]

def get_instrument_sounds(instrument, file_format):
    instrument_info = {}
    files = glob.glob(('sounds/{0}/*.{1}').format(instrument, file_format))
    for f in files:
        name = get_name_from_path(f)
        if name not in instrument_info:
            instrument_info[name] = {}
        instrument_info[name]['path'] = f
        instrument_info[name]['name']= name
    return instrument_info

app = Flask(__name__, static_url_path='')

@app.route('/sounds/<path:path>')
def send_sounds(path):
    return send_from_directory('sounds/', path)

@app.route('/js/<path:path>')
def send_js(path):
    return send_from_directory('js/', path)

@app.route('/node_modules/<path:path>')
def send_node_modules(path):
    return send_from_directory('node_modules/', path)

@app.route('/css/<path:path>')
def send_css(path):
    return send_from_directory('css/', path)

@app.route('/get_song')
def get_song():
    songname = request.args.get('songName')
    filepath = os.path.join('songs', songname+'.json')
    with open(filepath, 'r') as f:
        return f.read()
    return "404"

@app.route('/list_sounds')
def list_sounds():    
    instrument = request.args.get('instrument')
    file_format = get_file_format(instrument, request.headers['user-agent'])
    print (file_format)
    instrument_info = get_instrument_sounds(instrument, file_format)
    return jsonify(instrument_info)

@app.route('/list_songs')
def list_songs():
    songs = os.listdir('songs')
    song_info = {}
    song_info['songs'] = []
    for song in songs:
        song_info['songs'].append(
            {
                'path':song,
                'name':json.load(open('songs/'+song))['name']
            }
        )
    return jsonify(song_info)


@app.route("/")
def index():
   return render_template("index.html")

if __name__ == '__main__':  # pragma: no cover
    app.run(port=8000)