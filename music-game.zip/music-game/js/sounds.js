createjs.Sound.alternateExtensions = ["aiff"];

function loadAudioFile(path, id) {
  createjs.Sound.registerSound({ src: path, id: id, duration: 1 });
}
function handleLoadComplete(id) {
  createjs.Sound.play(id);
}

function loadSound(instrument) {
  fetch("/list_sounds?instrument=" + instrument)
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      for (var i = 0; i < Object.keys(data).length; i++) {
        const name = Object.keys(data)[i];
        loadAudioFile(data[name]["path"], name);
      }
    });
}

loadSound("piano");
loadSound("drums");
loadSound("metronome");
