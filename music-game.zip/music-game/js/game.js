// set up scene
let renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);
let camera = new THREE.PerspectiveCamera(
  45,
  window.innerWidth / window.innerHeight,
  1,
  500
);
camera.position.set(0, 0, 100);
camera.lookAt(0, 0, 0);
let scene = new THREE.Scene();
var domEvents = new THREEx.DomEvents(camera, renderer.domElement);

class SongButton {
  constructor(song, song_path) {
    this.song = song;
    this.song_path = song_path;
  }
}

class InstrumentButton {
  constructor(song, instrument) {
    this.song = song;
    this.instrument = instrument;
  }

  createGraphic(x_position) {
    var x = document.createElement("canvas");
    x.width = 1000;
    x.height = 1000;
    var xc = x.getContext("2d");
    x.width = 200;
    x.height = 128;
    xc.fillStyle = "white";
    xc.font = "30pt roboto";

    xc.fillText(this.instrument, 30, 30);

    var xm = new THREE.MeshBasicMaterial({
      map: new THREE.Texture(x),
      transparent: true,
    });
    xm.map.needsUpdate = true;

    var mesh = new THREE.Mesh(new THREE.CubeGeometry(20, 20, 1), xm);
    mesh.position.x = x_position;
    mesh.position.y = 0;
    mesh.position.z = 0;

    scene.add(mesh);
    this.graphic = mesh;
    domEvents.addEventListener(mesh, "click", (ev) => this.startGame(), false);
    return this.graphic;
  }
  startGame(event) {
    clearScene();
    game(this.instrument, this.song);
  }
}

class NoteGraphic {
  constructor(cube, note, time, instrument, lane, tempo) {
    this.cube = cube;
    this.note = note;
    this.time = time;
    this.lane = lane;
    this.instrument = instrument;
    this.added = false;
    this.listener = false;
    this.tempo = tempo;
  }

  animatePosition() {
    const tempo_factor = 1;
    if (this.lane == 1) {
      this.cube.position.y -= 0.5 * tempo_factor;
      this.cube.position.z += 0.136 * tempo_factor;
      this.cube.position.x -= 0.06 * tempo_factor;
    } else if (this.lane == 2) {
      this.cube.position.y -= 0.5 * tempo_factor;
      this.cube.position.z += 0.136 * tempo_factor;
      this.cube.position.x -= 0.03 * tempo_factor;
    } else if (this.lane == 3) {
      this.cube.position.y -= 0.5 * tempo_factor;
      this.cube.position.z += 0.136 * tempo_factor;
      this.cube.position.x += 0.03 * tempo_factor;
    } else if (this.lane == 4) {
      this.cube.position.y -= 0.5 * tempo_factor;
      this.cube.position.z += 0.136 * tempo_factor;
      this.cube.position.x += 0.06 * tempo_factor;
    }
  }
}

class Lane {
  constructor(id, x, y, z, color1, color2) {
    this.id = id;
    this.sphere = this.createSphere(color1, color2, x, y, z);
    this.nextNote = "";
    this.pressNote = "";
    this.nextNoteTime = 0;
    this.lightUp = false;
    this.last_time = 0;
  }

  addGlow() {
    let glow = this.addGlowGraphic(this.sphere);
    setTimeout(function () {
      scene.remove(glow);
    }, 300);
  }

  setNotes(notes) {
    this.notes = notes;
    this.setNotesPositions();
  }

  setNotesPositions() {
    for (let i = 0; i < this.notes.length; i++) {
      if (this.id == 1) {
        this.notes[i].cube.position.x = -20;
        this.notes[i].cube.position.y = 55;
        this.notes[i].cube.position.z = -15;
      } else if (this.id == 2) {
        this.notes[i].cube.position.x = -10;
        this.notes[i].cube.position.y = 55;
        this.notes[i].cube.position.z = -15;
      } else if (this.id == 3) {
        this.notes[i].cube.position.x = 10;
        this.notes[i].cube.position.y = 55;
        this.notes[i].cube.position.z = -15;
      } else if (this.id == 4) {
        this.notes[i].cube.position.x = 20;
        this.notes[i].cube.position.y = 55;
        this.notes[i].cube.position.z = -15;
      }
    }
  }

  getNextNote(time) {
    for (let i = 0; i < this.notes.length; i++) {
      if (time < this.notes[i].time && time > this.last_time) {
        this.nextNote = this.notes[i];

        if (i < this.notes.length) {
          this.nextNoteTime = this.notes[i].time;
        }
        this.last_time = this.nextNoteTime;
        return this.nextNote;
      }
    }
    return this.nextNote;
  }

  addGlowGraphic(sphere) {
    let customMaterial = new THREE.ShaderMaterial({
      uniforms: {
        c: { type: "f", value: 1.0 },
        p: { type: "f", value: 1.4 },
        glowColor: { type: "c", value: new THREE.Color(0xffffff) },
        viewVector: { type: "v3", value: camera.position },
      },
      vertexShader: `
        uniform vec3 viewVector;
        uniform float c;
        uniform float p;
        varying float intensity;
        void main() 
        {
            vec3 vNormal = normalize( normalMatrix * normal );
          vec3 vNormel = normalize( normalMatrix * viewVector );
          intensity = pow( c - dot(vNormal, vNormel), p );
          
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        }
      `,
      fragmentShader: `
        uniform vec3 glowColor;
        varying float intensity;
        void main() 
        {
          vec3 glow = glowColor * intensity;
            gl_FragColor = vec4( glow, 1.0 );
        }
      `,
      side: THREE.FrontSide,
      blending: THREE.AdditiveBlending,
      transparent: true,
    });

    let glow = new THREE.Mesh(sphere.geometry.clone(), customMaterial.clone());
    glow.position.set(sphere.position.x, sphere.position.y, sphere.position.z);
    glow.scale.multiplyScalar(1.2);
    scene.add(glow);
    return glow;
  }

  createSphere(color1, color2, radius, x, y) {
    let segments = 30,
      material = new THREE.ShaderMaterial({
        uniforms: {
          color1: {
            value: color1,
          },
          color2: {
            value: color2,
          },
        },
        vertexShader: `
        varying vec2 vUv;
    
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
        }
      `,
        fragmentShader: `
        uniform vec3 color1;
        uniform vec3 color2;
      
        varying vec2 vUv;
        
        void main() {
          
          gl_FragColor = vec4(mix(color1, color2, vUv.y), 1.0);
        }
      `,
      }),
      geometry = new THREE.SphereGeometry(
        radius,
        segments,
        segments,
        0,
        Math.PI,
        0,
        Math.PI
      );
    let sphere = new THREE.Mesh(geometry, material);
    sphere.position.set(x, y, 0);
    scene.add(sphere);
    return sphere;
  }
}

function clearScene() {
  while (scene.children.length > 0) {
    scene.remove(scene.children[0]);
  }
}

async function getSong(songName) {
  try {
    const promise = await fetch("/get_song?songName=" + songName);
    const data = await promise.json();
    return data;
  } catch (err) {
    console.log(err);
  }
}

async function getInstruments(songName) {
  const song = await getSong(songName);
  return song["instruments"];
}

async function createBeatMap(songName, instrument, delay_factor) {
  const song = await getSong(songName);
  // scaling factor by tempo/60 for all timing
  const tempo = 60 / song["tempo"];
  const instrumentInfo = {};
  const notesByLane = [[], [], [], []];
  const notes = song["notes"][instrument];

  for (let i = 0; i < Object.keys(notes).length; i++) {
    const noteInfo = notes[i];
    const note = noteInfo["note"];
    const time = noteInfo["time"];
    const lane = noteInfo["lane"];
    const cube = createCube(new THREE.Color(0xffffff));
    cube.scale.set(5, 5, 5);
    const noteGraphic = new NoteGraphic(
      cube,
      note,
      time * tempo + delay_factor,
      instrument,
      lane,
      tempo
    );

    notesByLane[lane - 1].push(noteGraphic);
  }
  instrumentInfo["notes"] = notesByLane;
  instrumentInfo["end"] = song["end"];
  return instrumentInfo;
}

let keysPressed = {};

document.addEventListener("keyup", (event) => {
  delete keysPressed[event.key];
});

function addToUserPlay(instrument, note, time, lane) {
  const noteObj = {
    note: note,
    time: time,
    lane: lane + 1,
  };
  user_played[instrument].push(noteObj);
}
function addClickHandler(instrument, lanes, time, delay_factor) {
  document.addEventListener(
    "keydown",
    function keyDown(event) {
      keysPressed[event.key] = true;

      if (event.repeat) {
        return;
      }

      let keyCode = event.which;
      if ((keyCode == 65 || keysPressed["a"]) && lanes[0].pressNote.note) {
        handleLoadComplete(lanes[0].pressNote.note);
        lanes[0].addGlow();
        addToUserPlay(
          instrument,
          lanes[0].pressNote.note,
          time - delay_factor,
          0
        );

        setTimeout(function () {
          document.removeEventListener("keydown", keyDown, false);
        }, 1000);
      }
      if ((keyCode == 83 || keysPressed["s"]) && lanes[1].pressNote.note) {
        handleLoadComplete(lanes[1].pressNote.note);
        lanes[1].addGlow();
        addToUserPlay(
          instrument,
          lanes[1].pressNote.note,
          time - delay_factor,
          1
        );

        setTimeout(function () {
          document.removeEventListener("keydown", keyDown, false);
        }, 1000);
      }
      if ((keyCode == 68 || keysPressed["d"]) && lanes[2].pressNote.note) {
        handleLoadComplete(lanes[2].pressNote.note);
        lanes[2].addGlow();
        addToUserPlay(
          instrument,
          lanes[2].pressNote.note,
          time - delay_factor,
          2
        );

        setTimeout(function () {
          document.removeEventListener("keydown", keyDown, false);
        }, 1000);
      }
      if ((keyCode == 70 || keysPressed["f"]) && lanes[3].pressNote.note) {
        handleLoadComplete(lanes[3].pressNote.note);
        lanes[3].addGlow();
        addToUserPlay(
          instrument,
          lanes[3].pressNote.note,
          time - delay_factor,
          3
        );

        setTimeout(function () {
          document.removeEventListener("keydown", keyDown, false);
        }, 1000);
      }
    },
    false
  );
}

function removeClickHandler() {
  document.removeEventListener("keydown", keyDown, false);
}

function createCube(color) {
  let geometry = new THREE.BoxGeometry();
  let material = new THREE.MeshBasicMaterial({ color: color });
  let cube = new THREE.Mesh(geometry, material);
  cube.translateOnAxis(new THREE.Vector3(0, 1.0, 0), window.innerHeight / 2);
  scene.add(cube);
  return cube;
}

function createLine(color, points) {
  let material = new THREE.LineBasicMaterial({ color: color });
  let geometry = new THREE.BufferGeometry().setFromPoints(points);
  let line = new THREE.Line(geometry, material);
  scene.add(line);
}

function createOutline() {
  let leftLine = [];
  leftLine.push(new THREE.Vector3(-20, 40, 5));
  leftLine.push(new THREE.Vector3(-150, -window.innerHeight / 2, 0));
  createLine(new THREE.Color(0x00ff00), leftLine);

  let rightLine = [];
  rightLine.push(new THREE.Vector3(20, 40, 5));
  rightLine.push(new THREE.Vector3(150, -window.innerHeight / 2, 0));
  createLine(new THREE.Color(0x00ff00), rightLine);

  let middleLine = [];
  middleLine.push(new THREE.Vector3(0, window.innerHeight / 2, 0));
  middleLine.push(new THREE.Vector3(0, -window.innerHeight / 2, 0));
  createLine(new THREE.Color(0x00ff00), middleLine);

  let middleLeftLine = [];
  middleLeftLine.push(new THREE.Vector3(-10, 40, 5));
  middleLeftLine.push(new THREE.Vector3(-75, -window.innerHeight / 2, 0));
  createLine(new THREE.Color(0x00ff00), middleLeftLine);

  let middleRightLine = [];
  middleRightLine.push(new THREE.Vector3(10, 40, 5));
  middleRightLine.push(new THREE.Vector3(75, -window.innerHeight / 2, 0));
  createLine(new THREE.Color(0x00ff00), middleRightLine);

  let bottomLine = [];
  bottomLine.push(new THREE.Vector3(-window.innerWidth / 2, -30, 0));
  bottomLine.push(new THREE.Vector3(window.innerWidth / 2, -30, -5));
  createLine(new THREE.Color(0x00ff00), bottomLine);

  renderer.render(scene, camera);
}

function createLanes() {
  let lane1 = new Lane(
    1,
    10,
    -34,
    -31,
    new THREE.Color(0x8ae176),
    new THREE.Color(0xbb2be1)
  );
  let lane2 = new Lane(
    2,
    10,
    -11,
    -31,
    new THREE.Color(0xbb2be1),
    new THREE.Color(0xe1b635)
  );
  let lane3 = new Lane(
    3,
    10,
    11,
    -31,
    new THREE.Color(0xe1b635),
    new THREE.Color(0x91a9e2)
  );
  let lane4 = new Lane(
    4,
    10,
    34,
    -31,
    new THREE.Color(0x49a0a2),
    new THREE.Color(0xd1d47e)
  );

  return [lane1, lane2, lane3, lane4];
}

const song = "picturesofmyheart";
const num_lanes = 4;
const delay_factor = 1;

let end = 100;
let clock = new THREE.Clock();
clock.stop();
let lanes = [];
let notes = [];
let songs = [];
let move_graphics = [];
let instrumentButtons = [];
let user_played = {};
let cur_instrument = "";

function reset() {
  console.log(user_played);
  move_graphics = [];
  songs = [];
  lanes = [];
  clock = new THREE.Clock();
  clock.stop();
  cur_instrument = "";
}

function game(instrument, song) {
  cur_instrument = instrument;
  user_played[instrument] = [];
  createBeatMap(song, cur_instrument, delay_factor).then((beatmap) => {
    lanes = createLanes();
    createOutline();

    for (let id = 0; id < num_lanes; id++) {
      lanes[id].setNotes(beatmap["notes"][id]);
    }

    end = beatmap["end"];
    clock.start();
  });
}

function selectInstruments(songName) {
  getInstruments(songName).then((instruments) => {
    let button_position = -60;
    let position_increment = 60;
    for (var i = 0; i < instruments.length; i++) {
      var instrumentButton = new InstrumentButton(songName, instruments[i]);
      instrumentButton.createGraphic(button_position);
      button_position += position_increment;
    }
  });
}

selectInstruments("picturesofmyheart");
// function startingScreen() {
//   fetch("/list_songs")
//     .then((response) => {
//       return response.json();
//     })
//     .then((data) => {
//       console.log(data);
//       songs = data["songs"];
//       let button_position = -30;
//       let position_increment = 60;
//       for (var i = 0; i < songs.length; i++) {
//         const songButton = new SongButton(songs[i]["name"], songs[i]["path"]);
//         const mesh = songButton.createGraphic(button_position);
//         button_position += position_increment;
//       }
//     });
// }

// startingScreen();
// game(instruments[0], "picturesofmyheart");

function animate() {
  requestAnimationFrame(animate);
  // cube.translateOnAxis(new THREE.Vector3(0.1, 0, 0), 1.0);
  const elapsedTime = clock.getElapsedTime();

  for (var i = 0; i < lanes.length; i++) {
    const lane = lanes[i];
    const nextNote = lane.getNextNote(elapsedTime);

    if (
      nextNote &&
      !nextNote.added &&
      lane.nextNoteTime > elapsedTime - 0.1 &&
      lane.nextNoteTime < elapsedTime + 0.1
    ) {
      move_graphics.push(nextNote);
      nextNote.added = true;
    }
  }
  const remove_arr = [];
  for (var i = 0; i < move_graphics.length; i++) {
    let noteGraphic = move_graphics[i];
    noteGraphic.animatePosition();
    if (noteGraphic.cube.position.y < -15 && !noteGraphic.listener) {
      noteGraphic.listener = true;
      lanes[noteGraphic.lane - 1].pressNote = noteGraphic;
      addClickHandler(cur_instrument, lanes, elapsedTime, delay_factor);
    }
    if (noteGraphic.cube.position.y < -40) {
      remove_arr.push(i);
      scene.remove(noteGraphic.cube);
    }
  }
  for (var i = remove_arr.length - 1; i > 0; i--) {
    move_graphics.splice(remove_arr[i], 1);
  }

  if (elapsedTime > end) {
    clock.stop();
    clearScene();
    selectInstruments(song);
    reset();
  }

  // scene.add(cube);
  renderer.render(scene, camera);
}

animate();
